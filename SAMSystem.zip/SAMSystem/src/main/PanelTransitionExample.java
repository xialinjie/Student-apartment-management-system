import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PanelTransitionExample extends JFrame {
    private JPanel panelContainer;
    private CardLayout cardLayout;
    private JPanel panel1;
    private JPanel panel2;
    private Timer timer;
    private int pos = 0;
    private final int SPEED = 10;

    public PanelTransitionExample() {
        setTitle("Panel Transition Animation");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        panelContainer = new JPanel(cardLayout);

        panel1 = new JPanel();
        panel1.setBackground(Color.RED);
        panelContainer.add(panel1, "Red Panel");

        panel2 = new JPanel();
        panel2.setBackground(Color.BLUE);
        panelContainer.add(panel2, "Blue Panel");

        add(panelContainer);

        timer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pos < getWidth()) {
                    pos += SPEED;
                    panel2.setLocation(-getWidth() + pos, 0);
                    panel1.setLocation(pos, 0);
                } else {
                    timer.stop();
                    cardLayout.show(panelContainer, "Blue Panel");
                    panel1.setLocation(0, 0);
                    panel2.setLocation(0, 0);
                }
            }
        });
    }

    private void startAnimation() {
        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                PanelTransitionExample frame = new PanelTransitionExample();
                frame.setVisible(true);
                frame.startAnimation();
            }
        });
    }
}
