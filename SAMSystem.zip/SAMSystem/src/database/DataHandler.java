package database;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package gui_tutorial;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.data.category.DefaultCategoryDataset;

public class DataHandler {
// DB details
    //private static final String dbURL = "jdbc:ucanaccess://Database1.accdb;sysSchema=true";

    private static final String dbURL = "jdbc:ucanaccess://sams.accdb;sysSchema=true";
    private static java.sql.Connection con;
    private static java.sql.Statement stm;
    private static java.sql.ResultSet rs;
    private static java.sql.ResultSetMetaData rsMeta;
    private static int columnCount;
    private static java.sql.PreparedStatement pstm;

    public static Vector<String> getTables() {
        Vector<String> l = new Vector<>();
        /*l.add("Employee");
        l.add("Dependant");
        l.add("Department");
        l.add("Project");
        l.add("Workson");*/
        String sqlQuery = "SELECT Name FROM sys.MSysObjects WHERE Type=1 AND Flags=0";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            stm = con.createStatement();
            rs = stm.executeQuery(sqlQuery);
            while (rs.next()) {
                // each row is an array of objects
                l.add((String) rs.getObject(1));
            }
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        } finally {
            try {
                if (null != con) {
                    // cleanup resources, once after processing
                    rs.close();
                    stm.close();
                    // and then finally close connection
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return l;
    }

    public static void searchRecords(String table) {
        String sqlQuery = "SELECT * FROM " + table;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            stm = con.createStatement(
                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                    java.sql.ResultSet.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sqlQuery);
            rsMeta = rs.getMetaData();
            columnCount = rsMeta.getColumnCount();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static Object[] getTitles(String table) {
        Object[] columnNames = new Object[columnCount];
        try {
            for (int col = columnCount; col > 0; col--) {
                columnNames[col - 1]
                        = rsMeta.getColumnName(col);
            }
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } finally {
            try {
                if (null != con) {
                    // cleanup resources, once after processing
                    rs.close();
                    stm.close();
                    // and then finally close connection
                    con.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return columnNames;
    }

    public static Object[][] getRows(String table) {
        searchRecords(table);
        Object[][] content;
        try {
// determine the number of rows
            rs.last();
            int number = rs.getRow();
            content = new Object[number][columnCount];
            rs.beforeFirst();
            int i = 0;
            while (rs.next()) {
// each row is an array of objects
                for (int col = 1; col <= columnCount; col++) {
                    content[i][col - 1] = rs.getObject(col);
                }
                i++;
            }
            return content;
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        }
        return null;
    }

    public static void insertInToMusic(String mName, String mLink) {
//        String sqlInsert = "INSERT INTO music (m_name, m_link) VALUES (" + mName + "," + mLink + ")";
        String sqlInsert = "INSERT INTO music (m_name, m_link) VALUES (?, ?)";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
////            stm = con.createStatement();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            int rows = stm.executeUpdate(mLink);

            pstm = con.prepareStatement(sqlInsert);
            pstm.setObject(1, mName);
            pstm.setObject(2, mLink);
            pstm.executeUpdate();

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void deleteMusic(String deleteID) {

        String sqlInsert = "DELETE FROM music WHERE m_id = ?";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlInsert);
            pstm.setObject(1, deleteID);
            pstm.executeUpdate();

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void uppdateMusic(String updateID, String mName, String mLink) {
        String sqlInsert = "UPDATE music SET m_name = ?, m_link = ? WHERE m_id = ?";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlInsert);
            pstm.setObject(1, mName);
            pstm.setObject(2, mLink);
            pstm.setObject(3, updateID);
            pstm.executeUpdate();

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static void insertInToClock(Integer available, String clockTime) {

        String sqlInsert = "INSERT INTO clock (available, clock_time) VALUES (?, ?)";
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlInsert);
            pstm.setObject(1, available);
            pstm.setObject(2, clockTime);
            pstm.executeUpdate();
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
    }

    public static DefaultCategoryDataset createDataset(String timeStamp) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        //-----------------------------------
        //String sqlQuery = "SELECT level FROM sleep_sound where time_stamp like ?";
        String sqlQuery = "SELECT sleep_level,time_stamp FROM sleep_sound where time_stamp like ?";

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, timeStamp + "%");
            rs = pstm.executeQuery();
//            stm = con.createStatement(
//                    java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    java.sql.ResultSet.CONCUR_READ_ONLY);
//            rs = stm.executeQuery(sqlQuery);
//            rsMeta = rs.getMetaData();
//            columnCount = rsMeta.getColumnCount();
            int count = 0;
            while (rs.next()) {
                count++;
                //System.out.println(rs.getString(2));
                dataset.addValue(rs.getInt(1), timeStamp, "" + count);

            }
//            for (int i = 0; i < columnCount; i++) {
//                rs.get
//                System.out.println(rsMeta.getColumnName(i));
//            }
        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }
        //------------------------------------

        return dataset;
    }

    //********************************************************************************
    public static int checkLogin(String username, String password) {

        int result = 0;
        String sqlQuery = "SELECT u_name FROM userInfo WHERE u_name = ? and u_password = ?";

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, username);
            pstm.setObject(2, password);
            rs = pstm.executeQuery();
            while (rs.next()) {
                result = 1;
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }

        return result;
    }
    
    //********************************************************************************
    public static int checkUsernameLogin(String username) {

        int result = 0;
        String sqlQuery = "SELECT u_id FROM userInfo WHERE u_name = ?";

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection(dbURL, "", "");
            pstm = con.prepareStatement(sqlQuery);
            pstm.setObject(1, username);
            rs = pstm.executeQuery();
            while (rs.next()) {
                result = 1;
            }

        } catch (ClassNotFoundException cnfex) {
            System.err.println("Issue with the JDBC driver.");
            System.exit(1); // terminate program - cannot recover
        } catch (java.sql.SQLException sqlex) {
            System.err.println(sqlex);
        } catch (Exception ex) {
            System.err.println(ex);
            //ex.printStackTrace();
        }

        return result;
    }

}
